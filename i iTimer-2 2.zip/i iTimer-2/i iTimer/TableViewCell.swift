//
//  TableViewCell.swift
//  i iTimer
//
//  Created by Student on 20.04.2022.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var table: UITableViewCell!
    @IBOutlet weak var timer: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
