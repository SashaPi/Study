//
//  RowTable.swift
//  PilnikKoL
//
//  Created by Student on 14.02.2022.
//

import WatchKit

class RowTable: NSObject {
    
    @IBOutlet weak var rowPicture: WKInterfaceImage!
    @IBOutlet weak var rowRecipeName: WKInterfaceLabel!

}
