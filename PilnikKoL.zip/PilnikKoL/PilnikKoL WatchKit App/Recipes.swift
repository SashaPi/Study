//
//  Recipes.swift
//  PilnikKoL
//
//  Created by Student on 14.02.2022.
//

import Foundation
