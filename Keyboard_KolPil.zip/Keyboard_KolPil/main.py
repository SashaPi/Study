# Import library
# from main import bot, dp
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import Message
API_TOKEN = '5754103265:AAF_9qIF6OP8CIBT31ZdSKoA-lDPrlcBSt4'

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

keyboard_markup = types.ReplyKeyboardMarkup(row_width=3)

# Array for keyboard
array_keyboard = [1, 2]

array_keyboard = ['Button1','Button2']

# Send message to admin
async def send_to_admin(dp):
        await bot.send_message(chat_id=5754103265, text="Bot start")

# Function of start bot
@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
        keyboard_markup.add(*(types.KeyboardButton(text) for text in array_keyboard))
        await message.answer(text='Hello!', reply_markup=keyboard_markup)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
