//
//  ViewController.swift
//  i iTimer
//
//  Created by Student on 23.03.2022.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var buttonStar: UIButton!
    @IBOutlet weak var buttonPause: UIButton!
    @IBOutlet weak var labelTime: UILabel!
    @IBOutlet weak var pictureBackground: UIImageView!
    @IBOutlet weak var picturePlus: UIImageView!
    @IBOutlet weak var buttonLap: UIButton!
    @IBOutlet weak var minitesecond1: UILabel!
    @IBOutlet weak var minitesecond2: UILabel!
    @IBOutlet weak var line1: UILabel!
    @IBOutlet weak var line2: UILabel!

    @IBAction func buttonPauseAction(_sender: Any) {
        
        labelTime.invalidate()
        labelTime.text = "00:00"
        
        buttonStar.isHidden = false
        buttonPause.isHidden = true
    }
    
    @IBAction func buttonLapaction(_sender: Any) {
    }
    
    @objc func timerUpdate() {
        let elapsed = -(self.labelTime.userInfo as! NSDate).timeIntervalSinceNow
        if elapsed < 60 {
            labelTime.text = String(format: "%.of", elapsed)
        }
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        buttonStar.isHidden = false
    }
    

}

