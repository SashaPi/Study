"""
This is a echo bot.
It echoes any incoming text messages.
"""

import logging

from aiogram import Bot, Dispatcher, executor, types

API_TOKEN = '5754103265:AAF_9qIF6OP8CIBT31ZdSKoA-lDPrlcBSt4'

# Configure logging
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)


@dp.message_handler(commands=['start'])
async def welcome(message: types.Message):
    """
    This handler will be called when user sends `/start` command
    """
    await message.reply("Привет......\n АРПАрпа")

@dp.message_handler(commands=['help'])
async def support(message: types.Message):
    """
    This handler will be called when user sends `/help` command
    """
    await message.answer("Не")

@dp.message_handler(regexp='(^cat[s]?$|puss)')
async def cats(message: types.Message):
    with open('data/cats.jpg', 'rb') as photo:
        '''
        # Old fashioned way:
        await bot.send_photo(
            message.chat.id,
            photo,
            caption='Cats are here 😺',
            reply_to_message_id=message.message_id,
        )
        '''

        await message.reply_photo(photo, caption='Cats are here 😺')


@dp.message_handler()
async def echo(message: types.Message):
    await message.answer_photo(types.InputFile('песик.jpeg'))


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)